import { Component, Input, Output, EventEmitter, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ReviewService } from '../../../services/review.service';
import { CustomerService } from '../../../services/customer.service';
import { CreateReviewDto } from '../../../models/review.model';

export interface Destination {
  id: string;
  name: string;
  country: string;
  flag: string;
}

@Component({
  selector: 'app-review-form',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './review-form.component.html',
  styleUrl: './review-form.component.css',
})
export class ReviewFormComponent {
  @Input() customerId = 'c001';
  @Input() customerName = 'Somchai Jaidee';
  @Input() bookingId = 'b000';
  @Output() submitted = new EventEmitter<void>();

  private reviewService = inject(ReviewService);
  private customerService = inject(CustomerService);
  private router = inject(Router);

  rating = signal(0);
  hoverRating = signal(0);
  title = signal('');
  comment = signal('');
  selectedTags = signal<string[]>([]);
  selectedDestination = signal<Destination | null>(null);
  submitting = signal(false);
  success = signal(false);

  readonly destinations: Destination[] = [
    { id: 'd001', name: 'Bali',       country: 'Indonesia', flag: '🇮🇩' },
    { id: 'd002', name: 'Tokyo',      country: 'Japan',     flag: '🇯🇵' },
    { id: 'd003', name: 'Santorini',  country: 'Greece',    flag: '🇬🇷' },
    { id: 'd004', name: 'Paris',      country: 'France',    flag: '🇫🇷' },
    { id: 'd005', name: 'New York',   country: 'USA',       flag: '🇺🇸' },
    { id: 'd006', name: 'Bangkok',    country: 'Thailand',  flag: '🇹🇭' },
    { id: 'd007', name: 'Singapore',  country: 'Singapore', flag: '🇸🇬' },
    { id: 'd008', name: 'London',     country: 'UK',        flag: '🇬🇧' },
    { id: 'd009', name: 'Dubai',      country: 'UAE',       flag: '🇦🇪' },
    { id: 'd010', name: 'Sydney',     country: 'Australia', flag: '🇦🇺' },
  ];

  readonly availableTags = [
    'beach', 'family-friendly', 'romantic', 'luxury', 'budget',
    'city-tour', 'culture', 'food', 'adventure', 'relaxing', 'great-food',
  ];

  readonly stars = [1, 2, 3, 4, 5];

  getInitials(): string {
    return this.customerName
      .split(' ').map((n) => n[0]).join('').toUpperCase().slice(0, 2);
  }

  selectDestination(dest: Destination): void {
    this.selectedDestination.set(dest);
  }

  setRating(star: number): void { this.rating.set(star); }
  setHover(star: number): void  { this.hoverRating.set(star); }
  clearHover(): void            { this.hoverRating.set(0); }

  isStarFilled(star: number): boolean {
    return star <= (this.hoverRating() || this.rating());
  }

  getRatingLabel(): string {
    const val = this.hoverRating() || this.rating();
    const labels: Record<number, string> = { 1: 'Poor', 2: 'Fair', 3: 'Good', 4: 'Very Good', 5: 'Excellent' };
    return labels[val] || 'Select rating';
  }

  toggleTag(tag: string): void {
    const current = this.selectedTags();
    const i = current.indexOf(tag);
    this.selectedTags.set(i === -1 ? [...current, tag] : current.filter((t) => t !== tag));
  }

  isTagSelected(tag: string): boolean {
    return this.selectedTags().includes(tag);
  }

  isFormValid(): boolean {
    return (
      this.rating() > 0 &&
      !!this.selectedDestination() &&
      this.title().trim().length >= 5 &&
      this.comment().trim().length >= 20
    );
  }

  onSubmit(): void {
    if (!this.isFormValid()) return;
    this.submitting.set(true);

    const dest = this.selectedDestination()!;
    const dto: CreateReviewDto = {
      customerId: this.customerId,
      customerName: this.customerName,
      destinationId: dest.id,
      destinationName: `${dest.name}, ${dest.country}`,
      bookingId: this.bookingId,
      rating: this.rating(),
      title: this.title(),
      comment: this.comment(),
      tags: this.selectedTags(),
    };

    this.reviewService.create(dto).subscribe({
      next: () => {
        this.submitting.set(false);
        this.success.set(true);
        this.submitted.emit();
        this.rating.set(0);
        this.title.set('');
        this.comment.set('');
        this.selectedTags.set([]);
        this.selectedDestination.set(null);
        setTimeout(() => { this.success.set(false); this.router.navigate(['/reviews']); }, 1500);
      },
    });
  }
}